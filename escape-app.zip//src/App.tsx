import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Plus,
  Search,
  Ghost,
  Skull,
  Camera,
  Key,
  Lock,
  Scroll,
  Map,
  Compass,
  Star,
  Crown,
  Sword,
  Gem,
  Music,
  Users,
  PenTool,
  Save,
  X,
  Trash2,
  CalendarDays,
  Image as ImageIcon,
  Settings,
  Upload,
  Check,
  ZoomIn,
  ZoomOut,
  AlertTriangle,
  BookOpen,
  LayoutList,
  LayoutGrid,
  Clock,
  Palette,
  Monitor,
  VenetianMask,
  Theater,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Calendar,
} from "lucide-react";

// Firebase Imports
import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithCustomToken,
  signInAnonymously,
  onAuthStateChanged,
  User as FirebaseUser,
} from "firebase/auth";
import {
  getFirestore,
  collection,
  addDoc,
  deleteDoc,
  updateDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  setDoc,
  getDoc,
  writeBatch,
} from "firebase/firestore";

// --- Firebase Initialization ---
// ⚠️ 請在這裡貼上你自己的 Firebase Config (從 Firebase Console 複製)
// 範例格式： const firebaseConfig = { apiKey: "...", ... };
const firebaseConfig = {
  // 請替換成您的設定
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

// 防止重複初始化
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const appId = "my-escape-app-v1"; // 固定 App ID

// --- Types ---
type GameMode = "escape" | "larp";
type LogStatus = "played" | "scheduled" | "wishlist";
type ThemeIconType =
  | "ghost"
  | "skull"
  | "camera"
  | "key"
  | "lock"
  | "scroll"
  | "map"
  | "compass"
  | "star"
  | "crown"
  | "sword"
  | "gem"
  | "music"
  | "users"
  | "coffee"
  | "mask"
  | "theater";
type ViewMode = "grid" | "list";

interface EscapeRoomLog {
  id: string;
  category: GameMode;
  studio: string;
  themeName: string;
  playDate: string;
  timeStart: string;
  timeEnd: string;
  duration: string;
  players: string;
  tags?: string;
  comment: string;
  status: LogStatus;
  icon: ThemeIconType;
  imageUrl?: string;
  createdAt: any;
}

// --- Style Objects (Fixed for React) ---
const SEIGAIHA_PATTERN: React.CSSProperties = {
  backgroundColor: "#4a6fa5",
  backgroundImage: `radial-gradient(circle at 100% 150%, #4a6fa5 24%, #5b80b2 25%, #5b80b2 28%, #4a6fa5 29%, #4a6fa5 36%, #5b80b2 36%, #5b80b2 40%, transparent 40%, transparent), radial-gradient(circle at 0 150%, #4a6fa5 24%, #5b80b2 25%, #5b80b2 28%, #4a6fa5 29%, #4a6fa5 36%, #5b80b2 36%, #5b80b2 40%, transparent 40%, transparent), radial-gradient(circle at 50% 100%, #5b80b2 10%, #4a6fa5 11%, #4a6fa5 23%, #5b80b2 24%, #5b80b2 30%, #4a6fa5 31%, #4a6fa5 43%, #5b80b2 44%, #5b80b2 50%, #4a6fa5 51%, #4a6fa5 63%, #5b80b2 64%, #5b80b2 71%, transparent 71%, transparent), radial-gradient(circle at 100% 50%, #5b80b2 5%, #4a6fa5 6%, #4a6fa5 15%, #5b80b2 16%, #5b80b2 20%, #4a6fa5 21%, #4a6fa5 30%, #5b80b2 31%, #5b80b2 35%, #4a6fa5 36%, #4a6fa5 45%, #5b80b2 46%, #5b80b2 49%, transparent 50%, transparent), radial-gradient(circle at 0 50%, #5b80b2 5%, #4a6fa5 6%, #4a6fa5 15%, #5b80b2 16%, #5b80b2 20%, #4a6fa5 21%, #4a6fa5 30%, #5b80b2 31%, #5b80b2 35%, #4a6fa5 36%, #4a6fa5 45%, #5b80b2 46%, #5b80b2 49%, transparent 50%, transparent)`,
  backgroundSize: "20px 10px",
};

const PAPER_TEXTURE: React.CSSProperties = {
  backgroundColor: "#fcf6e8",
  backgroundImage: `linear-gradient(rgba(0,0,0,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.02) 1px, transparent 1px)`,
  backgroundSize: "20px 20px",
  boxShadow: "inset 0 0 80px rgba(139, 69, 19, 0.15)",
};

// --- Data ---
interface ThemeInfo {
  name: string;
  duration: string;
  players: string;
  tags: string;
}

const ESCAPE_STUDIO_DATA: Record<string, ThemeInfo[]> = {
  覓見實境: [
    {
      name: "總督碟影",
      duration: "270",
      players: "6或9人",
      tags: "沉浸式實境解謎",
    },
  ],
  LoGin: [
    {
      name: "這個Case有點Big",
      duration: "110",
      players: "2~6人",
      tags: "密室逃脫",
    },
    {
      name: "利維德酒吧",
      duration: "180",
      players: "4~8人",
      tags: "酒窖&中央雙線",
    },
  ],
  不想工作室: [
    {
      name: "騎士詭途",
      duration: "160",
      players: "6~10人",
      tags: "解謎+成就+搜索",
    },
  ],
  瘋蜜工作室: [
    {
      name: "花月宴",
      duration: "150",
      players: "4~8人",
      tags: "沉浸+古風微恐",
    },
    { name: "黑洞", duration: "90", players: "2~6人", tags: "互動機關" },
    { name: "妖湯異聞錄", duration: "110", players: "3~6人", tags: "日式微恐" },
  ],
  開溜製作所: [
    {
      name: "洋洋海產店",
      duration: "90",
      players: "3~6人",
      tags: "沉浸式互動劇場",
    },
    {
      name: "黃衣小飛俠",
      duration: "120",
      players: "4~8人",
      tags: "沉浸式互動劇場",
    },
    { name: "卦", duration: "150", players: "6~8人", tags: "沉浸式劇場" },
  ],
  邏思起子: [
    {
      name: "永春醫院",
      duration: "110",
      players: "4~6人",
      tags: "機關厲害、恐怖",
    },
    { name: "囚聲", duration: "160", players: "8人", tags: "白色恐怖主題" },
  ],
  夢遊王國: [
    { name: "籠中鳥", duration: "100", players: "4~10人", tags: "日式驚悚" },
    { name: "安雅", duration: "120", players: "6~10人", tags: "泰式恐怖" },
  ],
  智慧獵人: [
    {
      name: "微笑迷藏+DLC",
      duration: "150",
      players: "4~8人",
      tags: "團隊合作",
    },
    {
      name: "被客人罵爆的我決定要逆天改命",
      duration: "100",
      players: "3~6人",
      tags: "歡樂主題",
    },
  ],
  月蝕迷願: [
    { name: "鬼降", duration: "120", players: "4~6人", tags: "極恐、即將復出" },
  ],
  放樂工作室: [
    {
      name: "失落密境:序章",
      duration: "90",
      players: "4~6人",
      tags: "場景逼真",
    },
  ],
};

const LARP_STUDIO_DATA: Record<string, ThemeInfo[]> = {
  玩硬遊戲館: [
    {
      name: "病嬌男孩的精分日記",
      duration: "210",
      players: "7人(不拘)",
      tags: "細思極恐代表作",
    },
    {
      name: "萌殺女僕咖啡廳",
      duration: "240",
      players: "2男4女",
      tags: "裝/反, 超可愛女僕裝",
    },
    {
      name: "青玉賭坊之玲瓏緣",
      duration: "240",
      players: "4男3女",
      tags: "裝/反, 古風歡樂機制",
    },
    {
      name: "神木屋",
      duration: "300",
      players: "3男3女",
      tags: "裝/反, 微恐情感",
    },
    {
      name: "繡花鞋-1980",
      duration: "240",
      players: "4男2女",
      tags: "裝/反, 大恐怖本",
    },
    {
      name: "洗劫巴黎所有的星星",
      duration: "240",
      players: "3男3女",
      tags: "裝/反, 情感",
    },
    {
      name: "芙蓉庄",
      duration: "210",
      players: "4男3女",
      tags: "裝/反, 歡樂恐怖機制",
    },
    { name: "畸形屋", duration: "180", players: "3男3女", tags: "裝/反, 微恐" },
    {
      name: "七日囚徒",
      duration: "270",
      players: "6人(不拘)",
      tags: "裝/反, 病嬌男孩外傳",
    },
  ],
  "衛斯理(天祥)": [
    {
      name: "鬼曼童",
      duration: "180",
      players: "5男2女",
      tags: "裝/反, 恐怖主題",
    },
    {
      name: "洗劫羅馬所有的情書",
      duration: "300",
      players: "3男3女",
      tags: "裝/反, 情感",
    },
    {
      name: "愛麗絲謀殺仙境",
      duration: "180",
      players: "3男3女",
      tags: "裝/反, 歡樂/推理",
    },
    {
      name: "點名",
      duration: "240",
      players: "4男4女",
      tags: "裝/反, 恐怖主題",
    },
    {
      name: "人皮燈籠",
      duration: "210",
      players: "3男3(4)女",
      tags: "裝/反, 恐怖主題",
    },
  ],
  "拉普星球(旗艦)": [
    {
      name: "兔偶公館",
      duration: "180",
      players: "3男4女",
      tags: "裝/反, 恐怖主題",
    },
    {
      name: "白鴉公館",
      duration: "180",
      players: "3男3女",
      tags: "裝/反, 恐怖主題",
    },
    {
      name: "黑羊公館",
      duration: "180",
      players: "3男3女",
      tags: "裝/反, 恐怖主題",
    },
    {
      name: "鯨魚馬戲團",
      duration: "300",
      players: "3男3女",
      tags: "裝/反, 情感",
    },
    {
      name: "仙劍 參商別",
      duration: "300",
      players: "3男3女",
      tags: "裝/反, 仙俠x情感",
    },
  ],
  宮月城: [
    {
      name: "血夜狼森",
      duration: "180",
      players: "5男3女",
      tags: "裝/反, 結合密室機關",
    },
    { name: "龍宴", duration: "210", players: "5男3女", tags: "裝/反" },
    {
      name: "青樓",
      duration: "240",
      players: "4男3女",
      tags: "裝/反, 建議反串",
    },
    {
      name: "焚炭森林 封館鬼屋版",
      duration: "210",
      players: "4男3女",
      tags: "極恐",
    },
  ],
  聚劇人生: [
    {
      name: "天空漫畫屋",
      duration: "240",
      players: "3男3女",
      tags: "裝/反, 情感",
    },
    {
      name: "送煞: 因財",
      duration: "240",
      players: "7人(不拘)",
      tags: "裝/反, 恐怖封館主題",
    },
  ],
};

const THEMES = [
  {
    id: "wood",
    name: "深邃木紋",
    color: "#3e2723",
    bgImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%235c3a21' fill-opacity='0.4'%3E%3Cpath d='M0 38.59l2.83-2.83 1.41 1.41L1.41 40H0v-1.41zM0 1.4l2.83 2.83 1.41-1.41L1.41 0H0v1.41zM38.59 40l-2.83-2.83 1.41-1.41L40 38.59V40h-1.41zM40 1.41l-2.83 2.83-1.41-1.41L38.59 0H40v1.41z'/%3E%3C/g%3E%3C/svg%3E")`,
  },
  {
    id: "tatami",
    name: "雅緻榻榻米",
    color: "#556b2f",
    bgImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h20v20H0V0zm10 10h10v10H10V10z' fill='%236b8e23' fill-opacity='0.2'/%3E%3C/svg%3E")`,
  },
  {
    id: "blackgold",
    name: "黑金和柄",
    color: "#1a1a1a",
    bgImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d4af37' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
  },
  {
    id: "sakura",
    name: "緋紅夜櫻",
    color: "#4a0404",
    bgImage: `url("data:image/svg+xml,%3Csvg width='52' height='26' viewBox='0 0 52 26' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffb7b2' fill-opacity='0.15'%3E%3Cpath d='M10 10c0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6h2c0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4v2c-3.314 0-6-2.686-6-6 0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6zm25.464-1.95l8.486 8.486-1.414 1.414-8.486-8.486 1.414-1.414z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
  },
];

const ICON_MAP: Record<ThemeIconType, any> = {
  ghost: Ghost,
  skull: Skull,
  camera: Camera,
  key: Key,
  lock: Lock,
  scroll: Scroll,
  map: Map,
  compass: Compass,
  star: Star,
  crown: Crown,
  sword: Sword,
  gem: Gem,
  music: Music,
  users: Users,
  coffee: CalendarDays,
  mask: VenetianMask,
  theater: Theater,
};

// --- Helpers ---
const resizeImage = (file: File, maxW = 400, maxH = 400): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxW) {
            height *= maxW / width;
            width = maxW;
          }
        } else {
          if (height > maxH) {
            width *= maxH / height;
            height = maxH;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.8));
      };
    };
    reader.onerror = (error) => reject(error);
  });
};

// --- Calendar Component ---
const CalendarView = ({
  logs,
  currentDate,
  onDateChange,
}: {
  logs: EscapeRoomLog[];
  currentDate: Date;
  onDateChange: (d: Date) => void;
}) => {
  const [selectedDayEvents, setSelectedDayEvents] = useState<{
    date: string;
    events: EscapeRoomLog[];
  } | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const blanks = Array.from({ length: firstDayOfMonth }, (_, i) => i);

  const getEventsForDay = (day: number) => {
    // 修正 padStart 問題，改用 slice
    const m = ("0" + (month + 1)).slice(-2);
    const d = ("0" + day).slice(-2);
    const dateStr = `${year}-${m}-${d}`;
    return logs
      .filter((l) => l.playDate === dateStr)
      .sort((a, b) =>
        (a.timeStart || "00:00").localeCompare(b.timeStart || "00:00")
      );
  };

  const handleDayClick = (day: number) => {
    const m = ("0" + (month + 1)).slice(-2);
    const d = ("0" + day).slice(-2);
    const dateStr = `${year}-${m}-${d}`;
    const events = getEventsForDay(day);
    if (events.length > 0) {
      setSelectedDayEvents({ date: dateStr, events });
    } else {
      setSelectedDayEvents(null);
    }
  };

  return (
    <div
      className="rounded-xl shadow-2xl border-2 border-stone-800 p-4 relative"
      style={PAPER_TEXTURE}
    >
      <div className="flex justify-between items-center mb-4">
        <button
          onClick={() => onDateChange(new Date(year, month - 1, 1))}
          className="p-2 hover:bg-stone-200 rounded-full transition-colors"
        >
          <ChevronLeft />
        </button>
        <h2 className="text-2xl font-bold text-stone-800 tracking-widest">
          {year}年 {month + 1}月
        </h2>
        <button
          onClick={() => onDateChange(new Date(year, month + 1, 1))}
          className="p-2 hover:bg-stone-200 rounded-full transition-colors"
        >
          <ChevronRight />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-1 mb-2 text-center font-bold text-stone-500 text-sm">
        <div className="text-red-600">日</div>
        <div>一</div>
        <div>二</div>
        <div>三</div>
        <div>四</div>
        <div>五</div>
        <div className="text-red-600">六</div>
      </div>
      <div className="grid grid-cols-7 gap-1 auto-rows-fr">
        {blanks.map((i) => (
          <div
            key={`blank-${i}`}
            className="min-h-[80px] bg-stone-900/5 rounded-lg"
          ></div>
        ))}
        {days.map((day) => {
          const events = getEventsForDay(day);
          const hasEvents = events.length > 0;
          return (
            <div
              key={day}
              onClick={() => handleDayClick(day)}
              className={`min-h-[80px] border rounded-lg p-1 relative transition-all cursor-pointer flex flex-col ${
                hasEvents
                  ? "bg-white border-red-300 shadow-md ring-1 ring-red-100"
                  : "bg-white/40 border-stone-300 hover:bg-white/80"
              }`}
            >
              <div
                className={`text-right text-sm font-bold mb-1 ${
                  hasEvents ? "text-stone-800" : "text-stone-400"
                }`}
              >
                {day}
              </div>
              <div className="flex flex-col gap-1 overflow-hidden flex-1">
                {events.map((ev) => (
                  <div
                    key={ev.id}
                    className={`text-[10px] px-1.5 py-0.5 rounded truncate font-bold text-white shadow-sm ${
                      ev.category === "escape" ? "bg-red-700" : "bg-indigo-700"
                    }`}
                  >
                    {ev.themeName}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      {selectedDayEvents && (
        <div className="absolute inset-0 z-20 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm rounded-xl animate-in fade-in duration-200">
          <div
            className="bg-[#fcf6e8] w-full max-w-sm rounded-lg shadow-2xl border-2 border-stone-800 overflow-hidden"
            style={PAPER_TEXTURE}
          >
            <div className="bg-stone-800 text-[#fcf6e8] p-3 flex justify-between items-center">
              <h3 className="font-bold flex items-center gap-2">
                <CalendarDays size={18} /> {selectedDayEvents.date} 行程
              </h3>
              <button
                onClick={() => setSelectedDayEvents(null)}
                className="hover:bg-stone-700 p-1 rounded-full"
              >
                <X size={18} />
              </button>
            </div>
            <div className="p-4 max-h-[400px] overflow-y-auto space-y-3">
              {selectedDayEvents.events.map((ev) => {
                const Icon = ICON_MAP[ev.icon] || Key;
                return (
                  <div
                    key={ev.id}
                    className="bg-white border border-stone-300 p-3 rounded shadow-sm flex gap-3 items-center"
                  >
                    <div className="w-12 h-12 flex-shrink-0 rounded-md overflow-hidden bg-stone-100 border border-stone-200 flex items-center justify-center relative">
                      {ev.imageUrl ? (
                        <img
                          src={ev.imageUrl}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Icon
                          size={24}
                          className={
                            ev.category === "escape"
                              ? "text-red-700"
                              : "text-indigo-700"
                          }
                        />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-stone-900 text-lg leading-none mb-1 truncate">
                        {ev.themeName}
                      </h4>
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-xs text-stone-500 font-bold truncate">
                          @{ev.studio}
                        </p>
                        {ev.timeStart && (
                          <div className="text-xs font-bold text-stone-800 bg-stone-100 px-1.5 py-0.5 rounded">
                            {ev.timeStart}~{ev.timeEnd}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// --- Adventure Card ---
const AdventureCard = ({
  log,
  onClick,
  isEditMode,
  isSelected,
  scale = 1,
  viewMode,
}: {
  log: EscapeRoomLog;
  onClick: () => void;
  isEditMode: boolean;
  isSelected: boolean;
  scale: number;
  viewMode: ViewMode;
}) => {
  const Icon = ICON_MAP[log.icon] || Key;

  if (viewMode === "list") {
    return (
      <div
        onClick={onClick}
        className={`flex items-center gap-4 bg-white/50 border border-stone-200 p-3 rounded-lg shadow-sm cursor-pointer transition-all duration-200 ${
          isSelected
            ? "bg-red-50 border-red-400 ring-1 ring-red-400"
            : "hover:bg-white/80 hover:shadow-md"
        }`}
      >
        {isEditMode && (
          <div
            className={`w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 ${
              isSelected
                ? "bg-red-600 border-red-600"
                : "border-stone-400 bg-white"
            }`}
          >
            {isSelected && (
              <Check size={12} className="text-white" strokeWidth={4} />
            )}
          </div>
        )}
        <div className="w-12 h-12 flex-shrink-0 rounded-md overflow-hidden bg-stone-100 border border-stone-200 flex items-center justify-center">
          {log.imageUrl ? (
            <img
              src={log.imageUrl}
              className="w-full h-full object-cover pointer-events-none"
            />
          ) : (
            <Icon size={24} className="text-stone-500" />
          )}
        </div>
        <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 gap-1">
          <div>
            <h3
              className={`font-bold text-stone-900 truncate ${
                isSelected ? "text-red-800" : ""
              }`}
            >
              {log.themeName}
            </h3>
            <div className="text-xs text-stone-500 font-bold truncate">
              @{log.studio}
            </div>
          </div>
          <div className="text-xs text-stone-600 flex flex-wrap gap-x-3 gap-y-1 items-center sm:justify-end">
            {log.status === "scheduled" && (
              <div className="flex items-center gap-1 bg-stone-200/50 px-1.5 py-0.5 rounded text-stone-800 font-bold">
                {log.playDate.slice(5).replace("-", "/")}
                {log.timeStart && (
                  <span className="ml-1 text-red-700">{log.timeStart}</span>
                )}
              </div>
            )}
            {log.duration && (
              <span className="flex items-center gap-1">
                <Clock size={10} /> {log.duration}分
              </span>
            )}
            {log.players && (
              <span className="flex items-center gap-1">
                <Users size={10} /> {log.players}
              </span>
            )}
            {log.tags && (
              <span className="text-[10px] bg-stone-200 text-stone-500 px-1.5 py-0.5 rounded-full truncate max-w-[120px]">
                {log.tags}
              </span>
            )}
          </div>
        </div>
      </div>
    );
  }

  const cardSize = 128 * scale;
  const iconSize = 56 * scale;
  const fontSizeTitle = Math.max(12, 14 * scale);
  const fontSizeSub = Math.max(10, 10 * scale);

  return (
    <div
      onClick={onClick}
      className={`group relative flex flex-col items-center cursor-pointer transition-all duration-300 ${
        isEditMode && !isSelected ? "opacity-60 hover:opacity-100" : ""
      } ${!isEditMode ? "hover:scale-105 hover:-translate-y-1" : ""} ${
        isSelected ? "scale-105 opacity-100" : ""
      }`}
      style={{ width: cardSize + 20 }}
    >
      {isSelected && (
        <div className="absolute -top-3 -right-3 z-30 animate-in zoom-in duration-200">
          <div className="bg-red-600 text-white rounded-full p-1.5 shadow-lg border-2 border-white">
            <Check size={16} strokeWidth={4} />
          </div>
        </div>
      )}
      <div
        className="relative mb-2"
        style={{ width: cardSize, height: cardSize }}
      >
        <div
          className={`w-full h-full bg-white rounded-2xl shadow-lg border-4 flex items-center justify-center relative z-10 overflow-hidden transition-colors ${
            isSelected
              ? "border-red-600 ring-4 ring-red-200"
              : "border-stone-100"
          }`}
        >
          {log.imageUrl ? (
            <img
              src={log.imageUrl}
              className="w-full h-full object-cover pointer-events-none"
            />
          ) : (
            <Icon
              size={iconSize}
              strokeWidth={1.5}
              className="text-stone-700"
            />
          )}
          {!log.imageUrl && (
            <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/60 to-transparent pointer-events-none"></div>
          )}
          {log.status === "scheduled" && (
            <div
              className="absolute bottom-0 inset-x-0 bg-stone-800/90 text-[#fcf6e8] py-1 text-center font-bold tracking-widest backdrop-blur-sm flex flex-col"
              style={{ fontSize: fontSizeSub }}
            >
              <span>{log.playDate.slice(5).replace("-", "/")}</span>
              {log.timeStart && (
                <span className="text-[0.8em] text-yellow-300">
                  {log.timeStart}~{log.timeEnd}
                </span>
              )}
            </div>
          )}
        </div>
        <div className="absolute bottom-[-6px] right-[-6px] w-full h-full bg-stone-900/10 rounded-2xl -z-0"></div>
      </div>
      <div className="text-center px-1 max-w-full z-20">
        <h3
          className={`font-bold leading-tight mb-0.5 break-words line-clamp-2 ${
            isSelected ? "text-red-800" : "text-stone-800"
          }`}
          style={{ fontSize: fontSizeTitle }}
        >
          {log.themeName}
        </h3>
        <p
          className="text-stone-500 font-bold truncate bg-white/50 px-2 rounded-full inline-block"
          style={{ fontSize: fontSizeSub }}
        >
          @{log.studio}
        </p>
      </div>
    </div>
  );
};

// --- Main App ---
export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [logs, setLogs] = useState<EscapeRoomLog[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [zoomLevel, setZoomLevel] = useState(1.0);
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [gameMode, setGameMode] = useState<GameMode>("escape");
  const [showCalendar, setShowCalendar] = useState(false);
  const [calendarDate, setCalendarDate] = useState(new Date());
  const [activeThemeId, setActiveThemeId] = useState("wood");
  const [customBg, setCustomBg] = useState<string | null>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState<Partial<EscapeRoomLog>>({
    studio: "",
    themeName: "",
    playDate: "",
    timeStart: "",
    timeEnd: "",
    duration: "",
    players: "",
    tags: "",
    comment: "",
    status: "wishlist",
    icon: "key",
    imageUrl: "",
  });
  const [editId, setEditId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isManualInput, setIsManualInput] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const initAuth = async () => {
      // 修正點 4: 移除 __initial_auth_token 檢查，直接使用匿名登入
      try {
        await signInAnonymously(auth);
      } catch (error) {
        console.error("Auth error:", error);
      }
    };
    initAuth();
    onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const settingsDoc = await getDoc(
          doc(db, "artifacts", appId, "users", u.uid, "settings", "preferences")
        );
        if (settingsDoc.exists()) {
          const data = settingsDoc.data();
          if (data.customBg) setCustomBg(data.customBg);
          if (data.activeThemeId) setActiveThemeId(data.activeThemeId);
          if (data.zoomLevel) setZoomLevel(data.zoomLevel);
          if (data.viewMode) setViewMode(data.viewMode);
          if (data.gameMode) setGameMode(data.gameMode);
        }
      }
    });
  }, []);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, "artifacts", appId, "users", user.uid, "escape_rooms"),
      orderBy("createdAt", "desc")
    );
    return onSnapshot(q, (snap) => {
      const allLogs = snap.docs.map(
        (d) => ({ id: d.id, ...d.data() } as EscapeRoomLog)
      );
      setLogs(allLogs);
    });
  }, [user]);

  const currentModeLogs = useMemo(
    () =>
      logs.filter((log) => {
        if (gameMode === "larp") return log.category === "larp";
        return log.category === "escape" || !log.category;
      }),
    [logs, gameMode]
  );
  const scheduledLogs = useMemo(
    () =>
      currentModeLogs
        .filter((l) => l.status === "scheduled")
        .sort(
          (a, b) =>
            new Date(a.playDate).getTime() - new Date(b.playDate).getTime()
        ),
    [currentModeLogs]
  );
  const wishlistLogs = useMemo(
    () => currentModeLogs.filter((l) => l.status === "wishlist"),
    [currentModeLogs]
  );
  const allScheduledLogs = useMemo(
    () => logs.filter((l) => l.status === "scheduled"),
    [logs]
  );

  const handleCustomBgUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (e.target.files && e.target.files[0] && user) {
      try {
        const base64 = await resizeImage(e.target.files[0], 1920, 1080);
        setCustomBg(base64);
        setActiveThemeId("custom");
        setShowThemeSelector(false);
        await setDoc(
          doc(
            db,
            "artifacts",
            appId,
            "users",
            user.uid,
            "settings",
            "preferences"
          ),
          { customBg: base64, activeThemeId: "custom" },
          { merge: true }
        );
      } catch (err) {
        console.error(err);
      }
    }
  };
  const selectTheme = async (themeId: string) => {
    setActiveThemeId(themeId);
    setShowThemeSelector(false);
    if (user)
      await setDoc(
        doc(
          db,
          "artifacts",
          appId,
          "users",
          user.uid,
          "settings",
          "preferences"
        ),
        { activeThemeId: themeId },
        { merge: true }
      );
  };
  const getActiveBackgroundStyle = () => {
    if (activeThemeId === "custom" && customBg)
      return {
        backgroundImage: `url(${customBg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
        backgroundColor: "#3e2723",
      };
    const theme = THEMES.find((t) => t.id === activeThemeId) || THEMES[0];
    return {
      backgroundImage: theme.bgImage,
      backgroundColor: theme.color,
      backgroundSize: "auto",
      backgroundAttachment: "fixed",
    };
  };
  const handleZoomChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const newZoom = parseFloat(e.target.value);
    setZoomLevel(newZoom);
    if (user)
      await setDoc(
        doc(
          db,
          "artifacts",
          appId,
          "users",
          user.uid,
          "settings",
          "preferences"
        ),
        { zoomLevel: newZoom },
        { merge: true }
      );
  };
  const toggleViewMode = async () => {
    const newMode = viewMode === "grid" ? "list" : "grid";
    setViewMode(newMode);
    if (user)
      await setDoc(
        doc(
          db,
          "artifacts",
          appId,
          "users",
          user.uid,
          "settings",
          "preferences"
        ),
        { viewMode: newMode },
        { merge: true }
      );
  };
  const toggleGameMode = async () => {
    const newMode = gameMode === "escape" ? "larp" : "escape";
    setGameMode(newMode);
    setSelectedIds(new Set());
    setIsEditMode(false);
    if (user)
      await setDoc(
        doc(
          db,
          "artifacts",
          appId,
          "users",
          user.uid,
          "settings",
          "preferences"
        ),
        { gameMode: newMode },
        { merge: true }
      );
  };
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsUploading(true);
      try {
        const base64 = await resizeImage(e.target.files[0]);
        setFormData({ ...formData, imageUrl: base64 });
      } catch (err) {
        alert("圖片處理失敗");
      } finally {
        setIsUploading(false);
      }
    }
  };
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const data = {
      ...formData,
      category: gameMode,
      createdAt: serverTimestamp(),
    };
    if (editId) {
      await updateDoc(
        doc(db, "artifacts", appId, "users", user.uid, "escape_rooms", editId),
        data
      );
    } else {
      await addDoc(
        collection(db, "artifacts", appId, "users", user.uid, "escape_rooms"),
        data
      );
    }
    setShowAddForm(false);
    setEditId(null);
  };
  const handleTimeStartChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const start = e.target.value;
    const duration = parseInt(formData.duration || "0");
    let end = formData.timeEnd;
    if (start && duration > 0) {
      const [h, m] = start.split(":").map(Number);
      const totalMins = h * 60 + m + duration;
      const endH = Math.floor(totalMins / 60) % 24;
      const endM = totalMins % 60;
      end = `${String(endH).padStart(2, "0")}:${String(endM).padStart(2, "0")}`;
    }
    setFormData({ ...formData, timeStart: start, timeEnd: end });
  };
  const getCurrentStudioData = () =>
    gameMode === "escape" ? ESCAPE_STUDIO_DATA : LARP_STUDIO_DATA;
  const handleStudioChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    if (value === "custom") {
      setIsManualInput(true);
      setFormData({
        ...formData,
        studio: "",
        themeName: "",
        duration: "",
        players: "",
        tags: "",
      });
    } else {
      setIsManualInput(false);
      setFormData({
        ...formData,
        studio: value,
        themeName: "",
        duration: "",
        players: "",
        tags: "",
      });
    }
  };
  const handleThemeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const themeName = e.target.value;
    if (!formData.studio || isManualInput) {
      setFormData({ ...formData, themeName });
      return;
    }
    const studioThemes = getCurrentStudioData()[formData.studio];
    const themeInfo = studioThemes?.find((t) => t.name === themeName);
    if (themeInfo) {
      setFormData({
        ...formData,
        themeName: themeInfo.name,
        duration: themeInfo.duration,
        players: themeInfo.players,
        tags: themeInfo.tags,
      });
    } else {
      setFormData({ ...formData, themeName });
    }
  };
  const toggleSelection = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedIds(newSet);
  };
  const performDelete = async () => {
    if (!user) return;
    setShowDeleteConfirm(false);
    try {
      const batch = writeBatch(db);
      selectedIds.forEach((id) => {
        const docRef = doc(
          db,
          "artifacts",
          appId,
          "users",
          user.uid,
          "escape_rooms",
          id
        );
        batch.delete(docRef);
      });
      await batch.commit();
      setSelectedIds(new Set());
      setIsEditMode(false);
    } catch (err) {
      alert("刪除失敗");
    }
  };
  const handleCardClick = (log: EscapeRoomLog) => {
    if (isEditMode) toggleSelection(log.id);
    else openEdit(log);
  };
  const openEdit = (log: EscapeRoomLog) => {
    setFormData(log);
    const studioData = getCurrentStudioData();
    const isPredefined = log.studio in studioData;
    setIsManualInput(!isPredefined);
    setEditId(log.id);
    setShowAddForm(true);
  };
  const openAdd = (status: LogStatus) => {
    setFormData({
      studio: "",
      themeName: "",
      playDate:
        status === "scheduled" ? new Date().toISOString().split("T")[0] : "",
      timeStart: "",
      timeEnd: "",
      duration: "",
      players: "",
      tags: "",
      comment: "",
      status,
      icon: gameMode === "escape" ? "key" : "mask",
      imageUrl: "",
    });
    setEditId(null);
    setIsManualInput(false);
    setShowAddForm(true);
  };

  return (
    <div className="relative font-serif select-none transition-all duration-500 min-h-screen flex flex-col">
      <div className="fixed inset-0 z-[-1]" style={getActiveBackgroundStyle()}>
        <div className="absolute inset-0 bg-black/20"></div>
      </div>
      <div className="fixed top-0 left-0 right-0 z-40 bg-stone-900/90 backdrop-blur-md border-b border-white/10 p-2 px-4 shadow-xl grid grid-cols-[1fr_auto_1fr] items-center gap-2">
        <div className="flex items-center gap-2 justify-start overflow-x-auto no-scrollbar">
          <button
            onClick={() => setShowThemeSelector(true)}
            className="bg-stone-700 hover:bg-stone-600 text-white p-2 rounded-full transition-colors flex-shrink-0"
          >
            <Palette size={18} />
          </button>
          <button
            onClick={toggleViewMode}
            className="bg-stone-700 hover:bg-stone-600 text-white p-2 rounded-full transition-colors flex-shrink-0"
          >
            <LayoutGrid size={18} />
          </button>
          <button
            onClick={() => setShowCalendar(!showCalendar)}
            className={`p-2 rounded-full transition-colors flex-shrink-0 ${
              showCalendar
                ? "bg-amber-600 text-white"
                : "bg-stone-700 hover:bg-stone-600 text-white"
            }`}
          >
            <Calendar size={18} />
          </button>
          {!showCalendar && (
            <div className="flex items-center gap-2 bg-stone-800/50 rounded-full px-2 py-1 border border-white/10 flex-shrink-0">
              <ZoomOut size={14} className="text-stone-400" />
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.1"
                value={zoomLevel}
                onChange={handleZoomChange}
                className="w-16 accent-red-600 h-1 bg-stone-600 rounded-lg appearance-none cursor-pointer"
              />
              <ZoomIn size={14} className="text-stone-400" />
            </div>
          )}
        </div>
        <button
          onClick={toggleGameMode}
          className="px-4 py-1.5 rounded-full bg-stone-800 border border-stone-600 shadow-md hover:bg-stone-700 active:scale-95 text-xs font-bold text-white tracking-widest flex-shrink-0 whitespace-nowrap"
        >
          {gameMode === "escape" ? "密室" : "劇本"}
        </button>
        <div className="flex justify-end">
          <button
            onClick={() => {
              setIsEditMode(!isEditMode);
              if (isEditMode) setSelectedIds(new Set());
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full font-bold transition-all border flex-shrink-0 ${
              isEditMode
                ? "bg-red-900 text-white border-red-700 animate-pulse"
                : "bg-stone-800 text-stone-200 border-stone-600 hover:bg-stone-700"
            }`}
          >
            <Settings size={16} />
            <span className="text-xs">{isEditMode ? "完成" : "整理"}</span>
          </button>
        </div>
      </div>
      {showThemeSelector && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg text-stone-800 flex items-center gap-2">
                <Palette size={20} /> 選擇卷軸風格
              </h3>
              <button
                onClick={() => setShowThemeSelector(false)}
                className="bg-stone-100 p-1 rounded-full"
              >
                <X size={18} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              {THEMES.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => selectTheme(theme.id)}
                  className={`relative h-20 rounded-lg border-2 overflow-hidden flex items-center justify-center text-white font-bold text-shadow-sm transition-all ${
                    activeThemeId === theme.id
                      ? "border-red-600 ring-2 ring-red-200 scale-105 shadow-md"
                      : "border-transparent opacity-80 hover:opacity-100"
                  }`}
                  style={{
                    background: theme.color,
                    backgroundImage: theme.bgImage,
                  }}
                >
                  <span className="relative z-10 drop-shadow-md">
                    {theme.name}
                  </span>
                </button>
              ))}
            </div>
            <div className="border-t border-stone-200 pt-4">
              <button
                onClick={() => bgInputRef.current?.click()}
                className={`w-full py-3 rounded-lg border-2 border-dashed border-stone-300 flex items-center justify-center gap-2 text-stone-500 hover:bg-stone-50 hover:border-stone-400 transition-all ${
                  activeThemeId === "custom"
                    ? "border-red-600 bg-red-50 text-red-700 font-bold"
                    : ""
                }`}
              >
                <Monitor size={18} />{" "}
                {activeThemeId === "custom"
                  ? "目前使用自訂背景"
                  : "上傳自訂背景"}
              </button>
              <input
                type="file"
                ref={bgInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleCustomBgUpload}
              />
            </div>
          </div>
        </div>
      )}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-stone-900 border border-stone-700 w-full max-w-sm rounded-xl p-6 shadow-2xl text-center">
            <div className="w-16 h-16 bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle size={32} className="text-red-500" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">
              確定要銷毀嗎？
            </h3>
            <p className="text-stone-400 mb-6 text-sm">此動作無法復原。</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-3 rounded-lg bg-stone-800 text-stone-300 font-bold hover:bg-stone-700"
              >
                取消
              </button>
              <button
                onClick={performDelete}
                className="flex-1 py-3 rounded-lg bg-red-600 text-white font-bold hover:bg-red-500 shadow-lg"
              >
                確認銷毀
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="max-w-7xl mx-auto w-full pt-20 pb-32 px-2 md:px-8 flex-1 flex flex-col items-center justify-start relative z-10">
        {showCalendar ? (
          <div className="w-full max-w-4xl animate-in zoom-in-95 duration-300">
            <CalendarView
              logs={allScheduledLogs}
              currentDate={calendarDate}
              onDateChange={setCalendarDate}
            />
          </div>
        ) : (
          <div
            className="relative w-full shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex rounded-sm overflow-hidden flex-1"
            style={{ minHeight: "75vh" }}
          >
            <div
              className="w-10 md:w-16 flex-shrink-0 relative z-20 border-r-2 border-slate-800/20"
              style={SEIGAIHA_PATTERN}
            >
              <div className="absolute inset-y-0 right-0 w-4 bg-gradient-to-l from-black/20 to-transparent"></div>
            </div>
            <div
              className="flex-1 relative flex flex-col"
              style={PAPER_TEXTURE}
            >
              <div className="flex items-center justify-center p-6 border-b-2 border-stone-800/10 relative">
                <div
                  className="text-center animate-in fade-in zoom-in duration-300"
                  key={gameMode}
                >
                  <h1 className="text-3xl font-bold text-stone-900 tracking-widest flex items-center gap-3">
                    {gameMode === "escape" ? "密室脫出" : "劇本殺卷"}
                  </h1>
                  <div
                    className={`w-12 h-1 mx-auto mt-2 rounded-full ${
                      gameMode === "escape" ? "bg-red-800" : "bg-purple-800"
                    }`}
                  ></div>
                </div>
              </div>
              <div className="flex-1 flex flex-col p-4 md:p-8 overflow-y-auto relative">
                <div className="mb-8 relative">
                  <div className="flex items-center gap-3 mb-4 sticky left-0">
                    <CalendarDays className="text-stone-800" size={24} />
                    <h2 className="text-xl font-bold text-stone-800">已排定</h2>
                    {!isEditMode && (
                      <button
                        onClick={() => openAdd("scheduled")}
                        className="ml-2 bg-stone-200 text-stone-600 p-1 rounded-full hover:bg-stone-300 transition-colors shadow-sm"
                      >
                        <Plus size={18} />
                      </button>
                    )}
                  </div>
                  {viewMode === "grid" ? (
                    <div className="flex gap-4 overflow-x-auto pb-4 px-2 snap-x items-start">
                      {scheduledLogs.length === 0 && (
                        <div className="w-full flex items-center justify-center text-stone-400 italic border-2 border-dashed border-stone-300 rounded-lg h-24">
                          尚無排定行程...
                        </div>
                      )}
                      {scheduledLogs.map((log) => (
                        <div key={log.id} className="flex-shrink-0 snap-center">
                          <AdventureCard
                            log={log}
                            onClick={() => handleCardClick(log)}
                            isEditMode={isEditMode}
                            isSelected={selectedIds.has(log.id)}
                            scale={zoomLevel}
                            viewMode="grid"
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {scheduledLogs.length === 0 && (
                        <div className="text-stone-400 italic p-4 text-center border-dashed border-2 border-stone-200 rounded">
                          尚無排定行程...
                        </div>
                      )}
                      {scheduledLogs.map((log) => (
                        <AdventureCard
                          key={log.id}
                          log={log}
                          onClick={() => handleCardClick(log)}
                          isEditMode={isEditMode}
                          isSelected={selectedIds.has(log.id)}
                          scale={zoomLevel}
                          viewMode="list"
                        />
                      ))}
                    </div>
                  )}
                </div>
                <div className="relative">
                  <div className="flex items-center gap-3 mb-4">
                    <PenTool className="text-stone-800" size={24} />
                    <h2 className="text-xl font-bold text-stone-800">
                      口袋名單
                    </h2>
                    {!isEditMode && (
                      <button
                        onClick={() => openAdd("wishlist")}
                        className="ml-2 bg-stone-200 text-stone-600 p-1 rounded-full hover:bg-stone-300 transition-colors shadow-sm"
                      >
                        <Plus size={18} />
                      </button>
                    )}
                  </div>
                  {viewMode === "grid" ? (
                    <div className="flex flex-wrap gap-6 justify-start">
                      {wishlistLogs.length === 0 && (
                        <div className="w-full text-center text-stone-400 py-10 italic">
                          暫無口袋名單...
                        </div>
                      )}
                      {wishlistLogs.map((log) => (
                        <AdventureCard
                          key={log.id}
                          log={log}
                          onClick={() => handleCardClick(log)}
                          isEditMode={isEditMode}
                          isSelected={selectedIds.has(log.id)}
                          scale={zoomLevel}
                          viewMode="grid"
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {wishlistLogs.length === 0 && (
                        <div className="text-stone-400 italic p-4 text-center">
                          暫無口袋名單...
                        </div>
                      )}
                      {wishlistLogs.map((log) => (
                        <AdventureCard
                          key={log.id}
                          log={log}
                          onClick={() => handleCardClick(log)}
                          isEditMode={isEditMode}
                          isSelected={selectedIds.has(log.id)}
                          scale={zoomLevel}
                          viewMode="list"
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div
              className="w-10 md:w-16 flex-shrink-0 relative z-20 border-l-2 border-slate-800/20"
              style={SEIGAIHA_PATTERN}
            >
              <div className="absolute inset-y-0 right-0 w-4 bg-gradient-to-l from-black/20 to-transparent"></div>
            </div>
          </div>
        )}
      </div>
      {isEditMode && (
        <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center pointer-events-none">
          <div className="bg-stone-900 text-white p-2 rounded-full shadow-2xl border border-stone-600 flex items-center gap-4 pointer-events-auto animate-in slide-in-from-bottom-10 mx-4 max-w-md w-full justify-between">
            <span className="font-bold text-sm px-4 whitespace-nowrap">
              {selectedIds.size === 0
                ? "點選項目"
                : `已選 ${selectedIds.size} 個`}
            </span>
            <button
              disabled={selectedIds.size === 0}
              onClick={() => setShowDeleteConfirm(true)}
              className={`bg-red-600 text-white px-6 py-2.5 rounded-full transition-all flex items-center gap-2 ${
                selectedIds.size > 0
                  ? "hover:bg-red-500 shadow-lg"
                  : "opacity-50 cursor-not-allowed"
              }`}
            >
              <Trash2 size={18} fill="white" />
              <span className="font-bold">銷毀</span>
            </button>
          </div>
        </div>
      )}
      {showAddForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#fcf6e8] w-full max-w-md shadow-2xl relative overflow-hidden rounded-sm border-2 border-stone-300 max-h-[90vh] overflow-y-auto">
            <div
              className="absolute inset-0 pointer-events-none opacity-30"
              style={PAPER_TEXTURE}
            ></div>
            <div className="relative z-10 p-6">
              <button
                onClick={() => setShowAddForm(false)}
                className="absolute top-4 right-4 text-stone-400 hover:text-stone-800 bg-stone-200 rounded-full p-1"
              >
                <X size={20} />
              </button>
              <h2 className="text-2xl font-bold text-stone-800 mb-6 flex items-center gap-2 border-b-2 border-red-800/30 pb-2 inline-block">
                {editId ? "修訂" : "新規"}
                {gameMode === "escape" ? "密室" : "劇本"}
              </h2>
              <form onSubmit={handleSave} className="space-y-5">
                <div className="flex gap-2 mb-4">
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({ ...formData, status: "scheduled" })
                    }
                    className={`flex-1 py-2 text-sm font-bold border-2 ${
                      formData.status === "scheduled"
                        ? "border-stone-800 bg-stone-800 text-[#fcf6e8]"
                        : "border-stone-300 text-stone-500"
                    }`}
                  >
                    已排定
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({ ...formData, status: "wishlist" })
                    }
                    className={`flex-1 py-2 text-sm font-bold border-2 ${
                      formData.status === "wishlist"
                        ? "border-stone-800 bg-stone-800 text-[#fcf6e8]"
                        : "border-stone-300 text-stone-500"
                    }`}
                  >
                    口袋名單
                  </button>
                </div>
                <div className="space-y-4">
                  {!isManualInput ? (
                    <>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          工作室 STUDIO
                        </label>
                        <div className="relative">
                          <select
                            required
                            className="w-full bg-stone-50 border border-stone-300 py-2 px-3 rounded-lg focus:border-red-800 focus:outline-none font-bold text-stone-800 appearance-none"
                            value={formData.studio}
                            onChange={handleStudioChange}
                          >
                            <option value="">請選擇工作室...</option>
                            {Object.keys(getCurrentStudioData()).map(
                              (studio) => (
                                <option key={studio} value={studio}>
                                  {studio}
                                </option>
                              )
                            )}
                            <option
                              value="custom"
                              className="font-bold text-red-800"
                            >
                              + 其他 / 手動輸入
                            </option>
                          </select>
                          <BookOpen
                            size={16}
                            className="absolute right-3 top-3 text-stone-400 pointer-events-none"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          {gameMode === "escape" ? "主題 THEME" : "劇本 SCRIPT"}
                        </label>
                        <div className="relative">
                          <select
                            required
                            disabled={!formData.studio}
                            className="w-full bg-stone-50 border border-stone-300 py-2 px-3 rounded-lg focus:border-red-800 focus:outline-none font-bold text-stone-800 appearance-none disabled:opacity-50"
                            value={formData.themeName}
                            onChange={handleThemeChange}
                          >
                            <option value="">
                              {formData.studio ? "請選擇..." : "請先選擇工作室"}
                            </option>
                            {formData.studio &&
                              getCurrentStudioData()[formData.studio]?.map(
                                (theme) => (
                                  <option key={theme.name} value={theme.name}>
                                    {theme.name}
                                  </option>
                                )
                              )}
                          </select>
                          <Search
                            size={16}
                            className="absolute right-3 top-3 text-stone-400 pointer-events-none"
                          />
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-red-600">
                          手動輸入模式
                        </span>
                        <button
                          type="button"
                          onClick={() => setIsManualInput(false)}
                          className="text-xs underline text-stone-500"
                        >
                          切換回清單
                        </button>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          工作室 STUDIO
                        </label>
                        <input
                          required
                          className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 font-bold text-stone-800"
                          value={formData.studio}
                          onChange={(e) =>
                            setFormData({ ...formData, studio: e.target.value })
                          }
                          placeholder="自行輸入工作室..."
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          {gameMode === "escape" ? "主題 THEME" : "劇本 SCRIPT"}
                        </label>
                        <input
                          required
                          className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 font-bold text-stone-800"
                          value={formData.themeName}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              themeName: e.target.value,
                            })
                          }
                          placeholder="自行輸入..."
                        />
                      </div>
                    </>
                  )}
                  {formData.status === "scheduled" && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          日期 DATE
                        </label>
                        <input
                          type="date"
                          required
                          className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 font-bold text-stone-800"
                          value={formData.playDate}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              playDate: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          時長 (分)
                        </label>
                        <input
                          type="text"
                          className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 font-bold text-stone-800"
                          value={formData.duration}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              duration: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          開始時間
                        </label>
                        <input
                          type="time"
                          className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 font-bold text-stone-800"
                          value={formData.timeStart}
                          onChange={handleTimeStartChange}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                          結束時間
                        </label>
                        <input
                          type="time"
                          className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 font-bold text-stone-800"
                          value={formData.timeEnd}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              timeEnd: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                        人數
                      </label>
                      <input
                        className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 text-stone-800"
                        value={formData.players}
                        onChange={(e) =>
                          setFormData({ ...formData, players: e.target.value })
                        }
                        placeholder="建議人數"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-stone-500 mb-1 tracking-widest">
                        標籤
                      </label>
                      <input
                        className="w-full bg-transparent border-b-2 border-stone-300 py-1 px-2 text-stone-800"
                        value={formData.tags}
                        onChange={(e) =>
                          setFormData({ ...formData, tags: e.target.value })
                        }
                        placeholder="特色..."
                      />
                    </div>
                  </div>
                  <div className="bg-white/60 p-4 rounded-lg border-2 border-dashed border-stone-300 text-center">
                    <label className="cursor-pointer block">
                      <div className="flex flex-col items-center gap-2">
                        {formData.imageUrl ? (
                          <div className="relative w-32 h-32 rounded-lg overflow-hidden shadow-sm border border-stone-200">
                            <img
                              src={formData.imageUrl}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                              <span className="text-white text-xs font-bold">
                                更換圖片
                              </span>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="w-12 h-12 bg-stone-200 rounded-full flex items-center justify-center text-stone-500">
                              <Upload size={24} />
                            </div>
                            <span className="text-sm text-stone-500 font-bold">
                              上傳封面圖片 (選填)
                            </span>
                          </>
                        )}
                      </div>
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                      />
                    </label>
                  </div>
                </div>
                <div className="pt-4 flex items-center justify-between gap-4">
                  <button
                    type="submit"
                    disabled={isUploading}
                    className="bg-red-900 text-[#fcf6e8] px-8 py-3 font-bold tracking-widest hover:bg-red-800 transition-colors shadow-lg flex-1 flex items-center justify-center gap-2 disabled:opacity-50"
                    style={{
                      clipPath:
                        "polygon(10px 0%, 100% 0%, 100% 100%, 0% 100%, 0% 10px)",
                    }}
                  >
                    <Save size={18} />
                    {isUploading ? "處理中..." : "紀錄保存"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
